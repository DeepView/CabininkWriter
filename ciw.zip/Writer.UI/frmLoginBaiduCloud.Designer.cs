﻿namespace Cabinink.Writer.UI
{
   partial class frmLoginBaiduCloud
   {
      /// <summary>
      /// 必需的设计器变量。
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// 清理所有正在使用的资源。
      /// </summary>
      /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows 窗体设计器生成的代码

      /// <summary>
      /// 设计器支持所需的方法 - 不要修改
      /// 使用代码编辑器修改此方法的内容。
      /// </summary>
      private void InitializeComponent()
      {
         this.pictureBox1 = new System.Windows.Forms.PictureBox();
         this.label1 = new System.Windows.Forms.Label();
         this.txtPassword = new MetroFramework.Controls.MetroTextBox();
         this.txtUserName = new MetroFramework.Controls.MetroTextBox();
         this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
         this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
         this.btnLogin = new MetroFramework.Controls.MetroButton();
         this.metroLink1 = new MetroFramework.Controls.MetroLink();
         ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
         this.SuspendLayout();
         // 
         // pictureBox1
         // 
         this.pictureBox1.Image = global::Cabinink.Properties.Resources.bdcloud_logo;
         this.pictureBox1.Location = new System.Drawing.Point(16, 24);
         this.pictureBox1.Name = "pictureBox1";
         this.pictureBox1.Size = new System.Drawing.Size(125, 47);
         this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
         this.pictureBox1.TabIndex = 0;
         this.pictureBox1.TabStop = false;
         // 
         // label1
         // 
         this.label1.AutoSize = true;
         this.label1.Font = new System.Drawing.Font("微软雅黑 Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
         this.label1.ForeColor = System.Drawing.Color.White;
         this.label1.Location = new System.Drawing.Point(138, 30);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(82, 31);
         this.label1.TabIndex = 1;
         this.label1.Text = "|  登录";
         // 
         // txtPassword
         // 
         this.txtPassword.FontSize = MetroFramework.MetroTextBoxSize.Medium;
         this.txtPassword.Lines = new string[0];
         this.txtPassword.Location = new System.Drawing.Point(59, 143);
         this.txtPassword.MaxLength = 32767;
         this.txtPassword.Name = "txtPassword";
         this.txtPassword.PasswordChar = '●';
         this.txtPassword.ScrollBars = System.Windows.Forms.ScrollBars.None;
         this.txtPassword.SelectedText = "";
         this.txtPassword.Size = new System.Drawing.Size(264, 28);
         this.txtPassword.TabIndex = 1;
         this.txtPassword.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.txtPassword.UseSelectable = true;
         // 
         // txtUserName
         // 
         this.txtUserName.FontSize = MetroFramework.MetroTextBoxSize.Medium;
         this.txtUserName.Lines = new string[0];
         this.txtUserName.Location = new System.Drawing.Point(59, 107);
         this.txtUserName.MaxLength = 32767;
         this.txtUserName.Name = "txtUserName";
         this.txtUserName.PasswordChar = '\0';
         this.txtUserName.ScrollBars = System.Windows.Forms.ScrollBars.None;
         this.txtUserName.SelectedText = "";
         this.txtUserName.Size = new System.Drawing.Size(264, 28);
         this.txtUserName.TabIndex = 0;
         this.txtUserName.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.txtUserName.UseSelectable = true;
         // 
         // metroLabel1
         // 
         this.metroLabel1.AutoSize = true;
         this.metroLabel1.Location = new System.Drawing.Point(16, 110);
         this.metroLabel1.Name = "metroLabel1";
         this.metroLabel1.Size = new System.Drawing.Size(37, 20);
         this.metroLabel1.TabIndex = 2;
         this.metroLabel1.Text = "账号";
         this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.metroLabel1.UseCustomBackColor = true;
         // 
         // metroLabel2
         // 
         this.metroLabel2.AutoSize = true;
         this.metroLabel2.Location = new System.Drawing.Point(16, 146);
         this.metroLabel2.Name = "metroLabel2";
         this.metroLabel2.Size = new System.Drawing.Size(37, 20);
         this.metroLabel2.TabIndex = 2;
         this.metroLabel2.Text = "密码";
         this.metroLabel2.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.metroLabel2.UseCustomBackColor = true;
         // 
         // btnLogin
         // 
         this.btnLogin.Location = new System.Drawing.Point(16, 241);
         this.btnLogin.Name = "btnLogin";
         this.btnLogin.Size = new System.Drawing.Size(307, 34);
         this.btnLogin.TabIndex = 2;
         this.btnLogin.Text = "登录到百度云(&L)";
         this.btnLogin.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.btnLogin.UseSelectable = true;
         this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
         // 
         // metroLink1
         // 
         this.metroLink1.FontWeight = MetroFramework.MetroLinkWeight.Light;
         this.metroLink1.Location = new System.Drawing.Point(150, 177);
         this.metroLink1.Name = "metroLink1";
         this.metroLink1.Size = new System.Drawing.Size(178, 23);
         this.metroLink1.TabIndex = 3;
         this.metroLink1.Text = "没有百度云账号？点击这里注册";
         this.metroLink1.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.metroLink1.UseCustomBackColor = true;
         this.metroLink1.UseSelectable = true;
         this.metroLink1.Click += new System.EventHandler(this.metroLink1_Click);
         // 
         // frmLoginBaiduCloud
         // 
         this.AcceptButton = this.btnLogin;
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
         this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
         this.ClientSize = new System.Drawing.Size(342, 293);
         this.Controls.Add(this.metroLink1);
         this.Controls.Add(this.btnLogin);
         this.Controls.Add(this.metroLabel2);
         this.Controls.Add(this.metroLabel1);
         this.Controls.Add(this.txtUserName);
         this.Controls.Add(this.txtPassword);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.pictureBox1);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "frmLoginBaiduCloud";
         this.ShowDrawIcon = false;
         this.Text = "";
         ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.PictureBox pictureBox1;
      private System.Windows.Forms.Label label1;
      private MetroFramework.Controls.MetroTextBox txtPassword;
      private MetroFramework.Controls.MetroTextBox txtUserName;
      private MetroFramework.Controls.MetroLabel metroLabel1;
      private MetroFramework.Controls.MetroLabel metroLabel2;
      private MetroFramework.Controls.MetroButton btnLogin;
      private MetroFramework.Controls.MetroLink metroLink1;
   }
}
