﻿namespace Cabinink.Writer.UI
{
   partial class frmSendIdentifyingCode
   {
      /// <summary>
      /// 必需的设计器变量。
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// 清理所有正在使用的资源。
      /// </summary>
      /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows 窗体设计器生成的代码

      /// <summary>
      /// 设计器支持所需的方法 - 不要修改
      /// 使用代码编辑器修改此方法的内容。
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         this.label2 = new System.Windows.Forms.Label();
         this.txtIdentifyingCode = new MetroFramework.Controls.MetroTextBox();
         this.btnSend = new MetroFramework.Controls.MetroButton();
         this.btnDone = new MetroFramework.Controls.MetroButton();
         this.tmrTicksCheck = new System.Windows.Forms.Timer(this.components);
         this.SuspendLayout();
         // 
         // label2
         // 
         this.label2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
         this.label2.ForeColor = System.Drawing.Color.Silver;
         this.label2.Location = new System.Drawing.Point(17, 54);
         this.label2.Name = "label2";
         this.label2.Size = new System.Drawing.Size(357, 77);
         this.label2.TabIndex = 1;
         this.label2.Text = "如果您发现您所填写的电子邮箱是错误的，或者前面的流程存在其他问题，您可以就现在关闭当前窗口并返回修改。若您已经确认刚才所填写的密码与电子邮箱没有错误，那么请单击下" +
    "面的按钮想您所填写的电子邮箱地址发送验证邮箱。";
         // 
         // txtIdentifyingCode
         // 
         this.txtIdentifyingCode.Lines = new string[0];
         this.txtIdentifyingCode.Location = new System.Drawing.Point(20, 147);
         this.txtIdentifyingCode.MaxLength = 32767;
         this.txtIdentifyingCode.Name = "txtIdentifyingCode";
         this.txtIdentifyingCode.PasswordChar = '\0';
         this.txtIdentifyingCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
         this.txtIdentifyingCode.SelectedText = "";
         this.txtIdentifyingCode.Size = new System.Drawing.Size(211, 23);
         this.txtIdentifyingCode.TabIndex = 2;
         this.txtIdentifyingCode.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.txtIdentifyingCode.UseSelectable = true;
         // 
         // btnSend
         // 
         this.btnSend.Location = new System.Drawing.Point(237, 147);
         this.btnSend.Name = "btnSend";
         this.btnSend.Size = new System.Drawing.Size(130, 23);
         this.btnSend.TabIndex = 3;
         this.btnSend.Text = "发送验证邮件(&S)";
         this.btnSend.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.btnSend.UseSelectable = true;
         this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
         // 
         // btnDone
         // 
         this.btnDone.Location = new System.Drawing.Point(251, 252);
         this.btnDone.Name = "btnDone";
         this.btnDone.Size = new System.Drawing.Size(116, 37);
         this.btnDone.TabIndex = 4;
         this.btnDone.Text = "完成注册(&D)";
         this.btnDone.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.btnDone.UseSelectable = true;
         this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
         // 
         // tmrTicksCheck
         // 
         this.tmrTicksCheck.Interval = 500;
         this.tmrTicksCheck.Tick += new System.EventHandler(this.tmrTicksCheck_Tick);
         // 
         // frmSendIdentifyingCode
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
         this.ClientSize = new System.Drawing.Size(387, 308);
         this.Controls.Add(this.btnDone);
         this.Controls.Add(this.btnSend);
         this.Controls.Add(this.txtIdentifyingCode);
         this.Controls.Add(this.label2);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "frmSendIdentifyingCode";
         this.Text = "发送验证码";
         //         this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSendIdentifyingCode_FormClosing);
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.Label label2;
      private MetroFramework.Controls.MetroTextBox txtIdentifyingCode;
      private MetroFramework.Controls.MetroButton btnSend;
      private MetroFramework.Controls.MetroButton btnDone;
      private System.Windows.Forms.Timer tmrTicksCheck;
   }
}
