﻿namespace Cabinink.Writer.UI
{
   partial class frmPictureTrim
   {
      /// <summary>
      /// 必需的设计器变量。
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// 清理所有正在使用的资源。
      /// </summary>
      /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows 窗体设计器生成的代码

      /// <summary>
      /// 设计器支持所需的方法 - 不要修改
      /// 使用代码编辑器修改此方法的内容。
      /// </summary>
      private void InitializeComponent()
      {
         this.picAvater = new System.Windows.Forms.PictureBox();
         this.tkbAreaSize = new MetroFramework.Controls.MetroTrackBar();
         this.btnOk = new MetroFramework.Controls.MetroButton();
         this.btnCancel = new MetroFramework.Controls.MetroButton();
         this.picPreview = new System.Windows.Forms.PictureBox();
         ((System.ComponentModel.ISupportInitialize)(this.picAvater)).BeginInit();
         ((System.ComponentModel.ISupportInitialize)(this.picPreview)).BeginInit();
         this.SuspendLayout();
         // 
         // picAvater
         // 
         this.picAvater.BackColor = System.Drawing.Color.Gray;
         this.picAvater.Location = new System.Drawing.Point(6, 43);
         this.picAvater.Name = "picAvater";
         this.picAvater.Size = new System.Drawing.Size(484, 484);
         this.picAvater.TabIndex = 0;
         this.picAvater.TabStop = false;
         this.picAvater.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picAvater_MouseMove);
         // 
         // tkbAreaSize
         // 
         this.tkbAreaSize.BackColor = System.Drawing.Color.Transparent;
         this.tkbAreaSize.Location = new System.Drawing.Point(496, 43);
         this.tkbAreaSize.Maximum = 260;
         this.tkbAreaSize.Minimum = 10;
         this.tkbAreaSize.Name = "tkbAreaSize";
         this.tkbAreaSize.Size = new System.Drawing.Size(200, 22);
         this.tkbAreaSize.TabIndex = 1;
         this.tkbAreaSize.Text = "metroTrackBar1";
         this.tkbAreaSize.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.tkbAreaSize.UseCustomBackColor = true;
         this.tkbAreaSize.Value = 100;
         // 
         // btnOk
         // 
         this.btnOk.Location = new System.Drawing.Point(496, 491);
         this.btnOk.Name = "btnOk";
         this.btnOk.Size = new System.Drawing.Size(95, 34);
         this.btnOk.TabIndex = 2;
         this.btnOk.Text = "确定剪裁";
         this.btnOk.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.btnOk.UseSelectable = true;
         // 
         // btnCancel
         // 
         this.btnCancel.Location = new System.Drawing.Point(601, 491);
         this.btnCancel.Name = "btnCancel";
         this.btnCancel.Size = new System.Drawing.Size(95, 34);
         this.btnCancel.TabIndex = 2;
         this.btnCancel.Text = "取消";
         this.btnCancel.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.btnCancel.UseSelectable = true;
         // 
         // picPreview
         // 
         this.picPreview.Location = new System.Drawing.Point(496, 285);
         this.picPreview.Name = "picPreview";
         this.picPreview.Size = new System.Drawing.Size(200, 200);
         this.picPreview.TabIndex = 3;
         this.picPreview.TabStop = false;
         // 
         // frmPictureTrim
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
         this.ClientSize = new System.Drawing.Size(702, 532);
         this.Controls.Add(this.picPreview);
         this.Controls.Add(this.btnCancel);
         this.Controls.Add(this.btnOk);
         this.Controls.Add(this.tkbAreaSize);
         this.Controls.Add(this.picAvater);
         this.MaximizeBox = false;
         this.Name = "frmPictureTrim";
         this.Text = "头像剪裁";
         this.Load += new System.EventHandler(this.frmPictureTrim_Load);
         ((System.ComponentModel.ISupportInitialize)(this.picAvater)).EndInit();
         ((System.ComponentModel.ISupportInitialize)(this.picPreview)).EndInit();
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.PictureBox picAvater;
      private MetroFramework.Controls.MetroTrackBar tkbAreaSize;
      private MetroFramework.Controls.MetroButton btnOk;
      private MetroFramework.Controls.MetroButton btnCancel;
      private System.Windows.Forms.PictureBox picPreview;
   }
}
