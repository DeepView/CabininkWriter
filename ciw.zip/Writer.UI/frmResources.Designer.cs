﻿namespace Cabinink.Writer.UI
{
   partial class frmResources
   {
      /// <summary>
      /// 必需的设计器变量。
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// 清理所有正在使用的资源。
      /// </summary>
      /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows 窗体设计器生成的代码

      /// <summary>
      /// 设计器支持所需的方法 - 不要修改
      /// 使用代码编辑器修改此方法的内容。
      /// </summary>
      private void InitializeComponent()
      {
         this.lsvExplorer = new System.Windows.Forms.ListView();
         this.chdFileName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
         this.chdFileSize = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
         this.chdCreationTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
         this.chdAttribute = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
         this.chdPath = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
         this.cmsContextMenu = new MaterialSkin.Controls.MaterialContextMenuStrip();
         this.打开资源文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.根据参数打开ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.Arguments = new System.Windows.Forms.ToolStripTextBox();
         this.确认参数并打开ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.删除文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.添加新文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.ofdAddResource = new System.Windows.Forms.OpenFileDialog();
         this.刷新ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
         this.cmsContextMenu.SuspendLayout();
         this.SuspendLayout();
         // 
         // lsvExplorer
         // 
         this.lsvExplorer.Activation = System.Windows.Forms.ItemActivation.OneClick;
         this.lsvExplorer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
         this.lsvExplorer.BorderStyle = System.Windows.Forms.BorderStyle.None;
         this.lsvExplorer.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chdFileName,
            this.chdFileSize,
            this.chdCreationTime,
            this.chdAttribute,
            this.chdPath});
         this.lsvExplorer.ContextMenuStrip = this.cmsContextMenu;
         this.lsvExplorer.Dock = System.Windows.Forms.DockStyle.Fill;
         this.lsvExplorer.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
         this.lsvExplorer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
         this.lsvExplorer.GridLines = true;
         this.lsvExplorer.Location = new System.Drawing.Point(4, 39);
         this.lsvExplorer.Name = "lsvExplorer";
         this.lsvExplorer.Size = new System.Drawing.Size(758, 379);
         this.lsvExplorer.TabIndex = 0;
         this.lsvExplorer.UseCompatibleStateImageBehavior = false;
         this.lsvExplorer.View = System.Windows.Forms.View.Details;
         this.lsvExplorer.DoubleClick += new System.EventHandler(this.lsvExplorer_DoubleClick);
         // 
         // chdFileName
         // 
         this.chdFileName.Text = "文件名";
         this.chdFileName.Width = 300;
         // 
         // chdFileSize
         // 
         this.chdFileSize.Text = "文件大小";
         this.chdFileSize.Width = 80;
         // 
         // chdCreationTime
         // 
         this.chdCreationTime.Text = "创建日期";
         this.chdCreationTime.Width = 200;
         // 
         // chdAttribute
         // 
         this.chdAttribute.Text = "属性";
         this.chdAttribute.Width = 80;
         // 
         // chdPath
         // 
         this.chdPath.Text = "完整路径";
         this.chdPath.Width = 640;
         // 
         // cmsContextMenu
         // 
         this.cmsContextMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
         this.cmsContextMenu.Depth = 0;
         this.cmsContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.打开资源文件ToolStripMenuItem,
            this.根据参数打开ToolStripMenuItem,
            this.刷新ToolStripMenuItem,
            this.删除文件ToolStripMenuItem,
            this.添加新文件ToolStripMenuItem});
         this.cmsContextMenu.MouseState = MaterialSkin.MouseStatus.HOVER;
         this.cmsContextMenu.Name = "cmsContextMenu";
         this.cmsContextMenu.Size = new System.Drawing.Size(153, 136);
         // 
         // 打开资源文件ToolStripMenuItem
         // 
         this.打开资源文件ToolStripMenuItem.Name = "打开资源文件ToolStripMenuItem";
         this.打开资源文件ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
         this.打开资源文件ToolStripMenuItem.Text = "打开";
         this.打开资源文件ToolStripMenuItem.Click += new System.EventHandler(this.打开资源文件ToolStripMenuItem_Click);
         // 
         // 根据参数打开ToolStripMenuItem
         // 
         this.根据参数打开ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Arguments,
            this.确认参数并打开ToolStripMenuItem});
         this.根据参数打开ToolStripMenuItem.Name = "根据参数打开ToolStripMenuItem";
         this.根据参数打开ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
         this.根据参数打开ToolStripMenuItem.Text = "根据参数打开";
         // 
         // Arguments
         // 
         this.Arguments.Name = "Arguments";
         this.Arguments.Size = new System.Drawing.Size(180, 23);
         this.Arguments.Text = "-arguments value";
         // 
         // 确认参数并打开ToolStripMenuItem
         // 
         this.确认参数并打开ToolStripMenuItem.Name = "确认参数并打开ToolStripMenuItem";
         this.确认参数并打开ToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
         this.确认参数并打开ToolStripMenuItem.Text = "确认参数并打开";
         this.确认参数并打开ToolStripMenuItem.Click += new System.EventHandler(this.确认参数并打开ToolStripMenuItem_Click);
         // 
         // 删除文件ToolStripMenuItem
         // 
         this.删除文件ToolStripMenuItem.Name = "删除文件ToolStripMenuItem";
         this.删除文件ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
         this.删除文件ToolStripMenuItem.Text = "删除文件";
         this.删除文件ToolStripMenuItem.Click += new System.EventHandler(this.删除文件ToolStripMenuItem_Click);
         // 
         // 添加新文件ToolStripMenuItem
         // 
         this.添加新文件ToolStripMenuItem.Name = "添加新文件ToolStripMenuItem";
         this.添加新文件ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
         this.添加新文件ToolStripMenuItem.Text = "添加新文件";
         this.添加新文件ToolStripMenuItem.Click += new System.EventHandler(this.添加新文件ToolStripMenuItem_Click);
         // 
         // ofdAddResource
         // 
         this.ofdAddResource.Filter = "所有文件|*.*";
         this.ofdAddResource.Title = "选择一个需要添加的资源文件";
         // 
         // 刷新ToolStripMenuItem
         // 
         this.刷新ToolStripMenuItem.Name = "刷新ToolStripMenuItem";
         this.刷新ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
         this.刷新ToolStripMenuItem.Text = "刷新";
         this.刷新ToolStripMenuItem.Click += new System.EventHandler(this.刷新ToolStripMenuItem_Click);
         // 
         // frmResources
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
         this.ClientSize = new System.Drawing.Size(766, 422);
         this.Controls.Add(this.lsvExplorer);
         this.MinimumSize = new System.Drawing.Size(449, 308);
         this.Name = "frmResources";
         this.Text = "资源文件管理";
         this.Load += new System.EventHandler(this.frmResources_Load);
         this.cmsContextMenu.ResumeLayout(false);
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.ListView lsvExplorer;
      private System.Windows.Forms.ColumnHeader chdFileName;
      private System.Windows.Forms.ColumnHeader chdFileSize;
      private System.Windows.Forms.ColumnHeader chdCreationTime;
      private System.Windows.Forms.ColumnHeader chdAttribute;
      private System.Windows.Forms.ColumnHeader chdPath;
      private MaterialSkin.Controls.MaterialContextMenuStrip cmsContextMenu;
      private System.Windows.Forms.ToolStripMenuItem 打开资源文件ToolStripMenuItem;
      private System.Windows.Forms.ToolStripMenuItem 根据参数打开ToolStripMenuItem;
      private System.Windows.Forms.ToolStripTextBox Arguments;
      private System.Windows.Forms.ToolStripMenuItem 删除文件ToolStripMenuItem;
      private System.Windows.Forms.ToolStripMenuItem 添加新文件ToolStripMenuItem;
      private System.Windows.Forms.ToolStripMenuItem 确认参数并打开ToolStripMenuItem;
      private System.Windows.Forms.OpenFileDialog ofdAddResource;
      private System.Windows.Forms.ToolStripMenuItem 刷新ToolStripMenuItem;
   }
}
