﻿namespace Cabinink.Writer.UI
{
   partial class frmWelcome
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.lblVersion = new MetroFramework.Controls.MetroLabel();
         this.lblCopyright = new MetroFramework.Controls.MetroLabel();
         this.SuspendLayout();
         // 
         // lblVersion
         // 
         this.lblVersion.AutoSize = true;
         this.lblVersion.BackColor = System.Drawing.Color.Transparent;
         this.lblVersion.Location = new System.Drawing.Point(535, 327);
         this.lblVersion.Name = "lblVersion";
         this.lblVersion.Size = new System.Drawing.Size(136, 20);
         this.lblVersion.TabIndex = 0;
         this.lblVersion.Text = "Version 1.0.1606.52";
         this.lblVersion.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.lblVersion.UseCustomBackColor = true;
         // 
         // lblCopyright
         // 
         this.lblCopyright.AutoSize = true;
         this.lblCopyright.BackColor = System.Drawing.Color.Transparent;
         this.lblCopyright.Location = new System.Drawing.Point(402, 348);
         this.lblCopyright.Name = "lblCopyright";
         this.lblCopyright.Size = new System.Drawing.Size(269, 20);
         this.lblCopyright.TabIndex = 0;
         this.lblCopyright.Text = "Copyrght(c)2011-2016,Cabinink Studio";
         this.lblCopyright.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.lblCopyright.UseCustomBackColor = true;
         this.lblCopyright.Click += new System.EventHandler(this.metroLabel1_Click);
         // 
         // frmWelcome
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.BackgroundImage = global::Cabinink.Properties.Resources.ciw_start_bgimg;
         this.ClientSize = new System.Drawing.Size(683, 384);
         this.Controls.Add(this.lblCopyright);
         this.Controls.Add(this.lblVersion);
         this.DoubleBuffered = true;
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
         this.MaximizeBox = false;
         this.MaximumSize = new System.Drawing.Size(683, 384);
         this.MinimizeBox = false;
         this.MinimumSize = new System.Drawing.Size(683, 384);
         this.Name = "frmWelcome";
         this.ShowIcon = false;
         this.ShowInTaskbar = false;
         this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
         this.Text = "Cabinink Writer";
         this.Load += new System.EventHandler(this.frmWelcome_Load);
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private MetroFramework.Controls.MetroLabel lblVersion;
      private MetroFramework.Controls.MetroLabel lblCopyright;
   }
}