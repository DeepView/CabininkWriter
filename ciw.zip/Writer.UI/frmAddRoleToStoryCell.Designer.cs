﻿namespace Cabinink.Writer.UI
{
   partial class frmAddRoleToStoryCell
   {
      /// <summary>
      /// 必需的设计器变量。
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// 清理所有正在使用的资源。
      /// </summary>
      /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows 窗体设计器生成的代码

      /// <summary>
      /// 设计器支持所需的方法 - 不要修改
      /// 使用代码编辑器修改此方法的内容。
      /// </summary>
      private void InitializeComponent()
      {
         this.lstRoles = new System.Windows.Forms.ListBox();
         this.btnAdd = new MetroFramework.Controls.MetroButton();
         this.metroButton2 = new MetroFramework.Controls.MetroButton();
         this.metroButton3 = new MetroFramework.Controls.MetroButton();
         this.SuspendLayout();
         // 
         // lstRoles
         // 
         this.lstRoles.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
         this.lstRoles.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
         this.lstRoles.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
         this.lstRoles.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
         this.lstRoles.FormattingEnabled = true;
         this.lstRoles.ItemHeight = 20;
         this.lstRoles.Location = new System.Drawing.Point(6, 44);
         this.lstRoles.Name = "lstRoles";
         this.lstRoles.Size = new System.Drawing.Size(248, 202);
         this.lstRoles.TabIndex = 0;
         // 
         // btnAdd
         // 
         this.btnAdd.Location = new System.Drawing.Point(260, 44);
         this.btnAdd.Name = "btnAdd";
         this.btnAdd.Size = new System.Drawing.Size(71, 29);
         this.btnAdd.TabIndex = 1;
         this.btnAdd.Text = "添加(&A)";
         this.btnAdd.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.btnAdd.UseSelectable = true;
         this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
         // 
         // metroButton2
         // 
         this.metroButton2.Location = new System.Drawing.Point(260, 79);
         this.metroButton2.Name = "metroButton2";
         this.metroButton2.Size = new System.Drawing.Size(71, 29);
         this.metroButton2.TabIndex = 1;
         this.metroButton2.Text = "刷新(&R)";
         this.metroButton2.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.metroButton2.UseSelectable = true;
         this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
         // 
         // metroButton3
         // 
         this.metroButton3.Location = new System.Drawing.Point(260, 217);
         this.metroButton3.Name = "metroButton3";
         this.metroButton3.Size = new System.Drawing.Size(71, 29);
         this.metroButton3.TabIndex = 1;
         this.metroButton3.Text = "取消(&C)";
         this.metroButton3.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.metroButton3.UseSelectable = true;
         this.metroButton3.Click += new System.EventHandler(this.metroButton3_Click);
         // 
         // frmAddRoleToStoryCell
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
         this.ClientSize = new System.Drawing.Size(338, 252);
         this.Controls.Add(this.metroButton3);
         this.Controls.Add(this.metroButton2);
         this.Controls.Add(this.btnAdd);
         this.Controls.Add(this.lstRoles);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "frmAddRoleToStoryCell";
         this.Text = "添加角色至故事线";
         this.Load += new System.EventHandler(this.frmAddRoleToStoryCell_Load);
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.ListBox lstRoles;
      private MetroFramework.Controls.MetroButton btnAdd;
      private MetroFramework.Controls.MetroButton metroButton2;
      private MetroFramework.Controls.MetroButton metroButton3;
   }
}
