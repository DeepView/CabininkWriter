﻿namespace Cabinink.Writer.UI
{
   partial class frmNotesOrResources
   {
      /// <summary>
      /// 必需的设计器变量。
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// 清理所有正在使用的资源。
      /// </summary>
      /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows 窗体设计器生成的代码

      /// <summary>
      /// 设计器支持所需的方法 - 不要修改
      /// 使用代码编辑器修改此方法的内容。
      /// </summary>
      private void InitializeComponent()
      {
         this.cmlNoteExplorer = new CommandLinkButton.CommandLink();
         this.cmlResExplorer = new CommandLinkButton.CommandLink();
         this.label1 = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // cmlNoteExplorer
         // 
         this.cmlNoteExplorer.FlatStyle = System.Windows.Forms.FlatStyle.System;
         this.cmlNoteExplorer.Image = null;
         this.cmlNoteExplorer.Location = new System.Drawing.Point(19, 110);
         this.cmlNoteExplorer.Name = "cmlNoteExplorer";
         this.cmlNoteExplorer.Size = new System.Drawing.Size(350, 60);
         this.cmlNoteExplorer.SupplementalExplanation = "笔记浏览器是一个用来管理与创建笔记的模块";
         this.cmlNoteExplorer.TabIndex = 1;
         this.cmlNoteExplorer.Text = "进入笔记浏览器(&N)";
         this.cmlNoteExplorer.UseVisualStyleBackColor = true;
         this.cmlNoteExplorer.Click += new System.EventHandler(this.cmlNoteExplorer_Click);
         // 
         // cmlResExplorer
         // 
         this.cmlResExplorer.FlatStyle = System.Windows.Forms.FlatStyle.System;
         this.cmlResExplorer.Image = null;
         this.cmlResExplorer.Location = new System.Drawing.Point(19, 193);
         this.cmlResExplorer.Name = "cmlResExplorer";
         this.cmlResExplorer.Size = new System.Drawing.Size(350, 60);
         this.cmlResExplorer.SupplementalExplanation = "资源文件管理器是一个用来管理作品项目所需资源的模块";
         this.cmlResExplorer.TabIndex = 2;
         this.cmlResExplorer.Text = "进入资源文件管理器(R)";
         this.cmlResExplorer.UseVisualStyleBackColor = true;
         this.cmlResExplorer.Click += new System.EventHandler(this.cmlResExplorer_Click);
         // 
         // label1
         // 
         this.label1.AutoSize = true;
         this.label1.Font = new System.Drawing.Font("微软雅黑 Light", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
         this.label1.ForeColor = System.Drawing.Color.White;
         this.label1.Location = new System.Drawing.Point(16, 35);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(134, 31);
         this.label1.TabIndex = 0;
         this.label1.Text = "资料与笔记";
         // 
         // frmNotesOrResources
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
         this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
         this.ClientSize = new System.Drawing.Size(388, 282);
         this.Controls.Add(this.label1);
         this.Controls.Add(this.cmlResExplorer);
         this.Controls.Add(this.cmlNoteExplorer);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "frmNotesOrResources";
         this.ShowDrawIcon = false;
         this.Text = "";
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private CommandLinkButton.CommandLink cmlNoteExplorer;
      private System.Windows.Forms.Label label1;
      private CommandLinkButton.CommandLink cmlResExplorer;
   }
}
