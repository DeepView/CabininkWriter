﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Cabinink.Writer.UI
{
   public partial class frmSearchAndReplace : Cabinink.Writer.UI.VsSkinFormBase
   {
      public frmSearchAndReplace()
      {
         InitializeComponent();
      }
   }
}
