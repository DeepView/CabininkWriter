﻿namespace Cabinink.Writer.UI
{
   partial class frmCreateCompendium
   {
      /// <summary>
      /// 必需的设计器变量。
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// 清理所有正在使用的资源。
      /// </summary>
      /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows 窗体设计器生成的代码

      /// <summary>
      /// 设计器支持所需的方法 - 不要修改
      /// 使用代码编辑器修改此方法的内容。
      /// </summary>
      private void InitializeComponent()
      {
         this.hltYear = new Cabinink.Writer.UI.HaveLabelTextBox();
         this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
         this.hltMonth = new Cabinink.Writer.UI.HaveLabelTextBox();
         this.hltDay = new Cabinink.Writer.UI.HaveLabelTextBox();
         this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
         this.cmbCategory = new MetroFramework.Controls.MetroComboBox();
         this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
         this.lstRoles = new System.Windows.Forms.ListBox();
         this.btnAdd = new MetroFramework.Controls.MetroButton();
         this.btnRemove = new MetroFramework.Controls.MetroButton();
         this.btnClearAll = new MetroFramework.Controls.MetroButton();
         this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
         this.txtPlace = new MetroFramework.Controls.MetroTextBox();
         this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
         this.txtStory = new MetroFramework.Controls.MetroTextBox();
         this.btnOk = new MetroFramework.Controls.MetroButton();
         this.btnCancel = new MetroFramework.Controls.MetroButton();
         this.SuspendLayout();
         // 
         // hltYear
         // 
         this.hltYear.BackColor = System.Drawing.Color.Transparent;
         this.hltYear.Context = "";
         this.hltYear.Description = "年";
         this.hltYear.Location = new System.Drawing.Point(61, 56);
         this.hltYear.Name = "hltYear";
         this.hltYear.Size = new System.Drawing.Size(108, 24);
         this.hltYear.TabIndex = 0;
         // 
         // metroLabel1
         // 
         this.metroLabel1.AutoSize = true;
         this.metroLabel1.Location = new System.Drawing.Point(18, 56);
         this.metroLabel1.Name = "metroLabel1";
         this.metroLabel1.Size = new System.Drawing.Size(37, 20);
         this.metroLabel1.TabIndex = 1;
         this.metroLabel1.Text = "日期";
         this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.metroLabel1.UseCustomBackColor = true;
         // 
         // hltMonth
         // 
         this.hltMonth.BackColor = System.Drawing.Color.Transparent;
         this.hltMonth.Context = "";
         this.hltMonth.Description = "月";
         this.hltMonth.Location = new System.Drawing.Point(172, 56);
         this.hltMonth.Name = "hltMonth";
         this.hltMonth.Size = new System.Drawing.Size(108, 24);
         this.hltMonth.TabIndex = 1;
         // 
         // hltDay
         // 
         this.hltDay.BackColor = System.Drawing.Color.Transparent;
         this.hltDay.Context = "";
         this.hltDay.Description = "日";
         this.hltDay.Location = new System.Drawing.Point(281, 56);
         this.hltDay.Name = "hltDay";
         this.hltDay.Size = new System.Drawing.Size(108, 24);
         this.hltDay.TabIndex = 2;
         // 
         // metroLabel2
         // 
         this.metroLabel2.AutoSize = true;
         this.metroLabel2.Location = new System.Drawing.Point(18, 91);
         this.metroLabel2.Name = "metroLabel2";
         this.metroLabel2.Size = new System.Drawing.Size(37, 20);
         this.metroLabel2.TabIndex = 1;
         this.metroLabel2.Text = "分类";
         this.metroLabel2.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.metroLabel2.UseCustomBackColor = true;
         // 
         // cmbCategory
         // 
         this.cmbCategory.FormattingEnabled = true;
         this.cmbCategory.ItemHeight = 24;
         this.cmbCategory.Items.AddRange(new object[] {
            "故事背景",
            "正文",
            "外传"});
         this.cmbCategory.Location = new System.Drawing.Point(61, 86);
         this.cmbCategory.Name = "cmbCategory";
         this.cmbCategory.Size = new System.Drawing.Size(328, 30);
         this.cmbCategory.TabIndex = 3;
         this.cmbCategory.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.cmbCategory.UseSelectable = true;
         // 
         // metroLabel3
         // 
         this.metroLabel3.AutoSize = true;
         this.metroLabel3.Location = new System.Drawing.Point(18, 128);
         this.metroLabel3.Name = "metroLabel3";
         this.metroLabel3.Size = new System.Drawing.Size(37, 20);
         this.metroLabel3.TabIndex = 1;
         this.metroLabel3.Text = "角色";
         this.metroLabel3.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.metroLabel3.UseCustomBackColor = true;
         // 
         // lstRoles
         // 
         this.lstRoles.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
         this.lstRoles.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
         this.lstRoles.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
         this.lstRoles.ForeColor = System.Drawing.Color.DarkGray;
         this.lstRoles.FormattingEnabled = true;
         this.lstRoles.ItemHeight = 20;
         this.lstRoles.Location = new System.Drawing.Point(61, 128);
         this.lstRoles.Name = "lstRoles";
         this.lstRoles.Size = new System.Drawing.Size(219, 82);
         this.lstRoles.TabIndex = 7;
         // 
         // btnAdd
         // 
         this.btnAdd.Location = new System.Drawing.Point(286, 128);
         this.btnAdd.Name = "btnAdd";
         this.btnAdd.Size = new System.Drawing.Size(103, 23);
         this.btnAdd.TabIndex = 4;
         this.btnAdd.Text = "添加(&A)";
         this.btnAdd.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.btnAdd.UseSelectable = true;
         this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
         // 
         // btnRemove
         // 
         this.btnRemove.Location = new System.Drawing.Point(286, 157);
         this.btnRemove.Name = "btnRemove";
         this.btnRemove.Size = new System.Drawing.Size(103, 23);
         this.btnRemove.TabIndex = 5;
         this.btnRemove.Text = "移除(&R)";
         this.btnRemove.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.btnRemove.UseSelectable = true;
         this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
         // 
         // btnClearAll
         // 
         this.btnClearAll.Location = new System.Drawing.Point(286, 186);
         this.btnClearAll.Name = "btnClearAll";
         this.btnClearAll.Size = new System.Drawing.Size(103, 23);
         this.btnClearAll.TabIndex = 6;
         this.btnClearAll.Text = "清除全部(&C)";
         this.btnClearAll.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.btnClearAll.UseSelectable = true;
         this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
         // 
         // metroLabel4
         // 
         this.metroLabel4.AutoSize = true;
         this.metroLabel4.Location = new System.Drawing.Point(18, 222);
         this.metroLabel4.Name = "metroLabel4";
         this.metroLabel4.Size = new System.Drawing.Size(37, 20);
         this.metroLabel4.TabIndex = 1;
         this.metroLabel4.Text = "地点";
         this.metroLabel4.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.metroLabel4.UseCustomBackColor = true;
         // 
         // txtPlace
         // 
         this.txtPlace.Lines = new string[0];
         this.txtPlace.Location = new System.Drawing.Point(61, 222);
         this.txtPlace.MaxLength = 32767;
         this.txtPlace.Name = "txtPlace";
         this.txtPlace.PasswordChar = '\0';
         this.txtPlace.ScrollBars = System.Windows.Forms.ScrollBars.None;
         this.txtPlace.SelectedText = "";
         this.txtPlace.Size = new System.Drawing.Size(328, 23);
         this.txtPlace.TabIndex = 8;
         this.txtPlace.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.txtPlace.UseSelectable = true;
         // 
         // metroLabel5
         // 
         this.metroLabel5.AutoSize = true;
         this.metroLabel5.Location = new System.Drawing.Point(18, 258);
         this.metroLabel5.Name = "metroLabel5";
         this.metroLabel5.Size = new System.Drawing.Size(37, 20);
         this.metroLabel5.TabIndex = 1;
         this.metroLabel5.Text = "故事";
         this.metroLabel5.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.metroLabel5.UseCustomBackColor = true;
         // 
         // txtStory
         // 
         this.txtStory.Lines = new string[0];
         this.txtStory.Location = new System.Drawing.Point(61, 258);
         this.txtStory.MaxLength = 32767;
         this.txtStory.Multiline = true;
         this.txtStory.Name = "txtStory";
         this.txtStory.PasswordChar = '\0';
         this.txtStory.ScrollBars = System.Windows.Forms.ScrollBars.Both;
         this.txtStory.SelectedText = "";
         this.txtStory.Size = new System.Drawing.Size(328, 93);
         this.txtStory.TabIndex = 9;
         this.txtStory.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.txtStory.UseSelectable = true;
         // 
         // btnOk
         // 
         this.btnOk.Location = new System.Drawing.Point(222, 372);
         this.btnOk.Name = "btnOk";
         this.btnOk.Size = new System.Drawing.Size(78, 28);
         this.btnOk.TabIndex = 10;
         this.btnOk.Text = "创建(&O)";
         this.btnOk.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.btnOk.UseSelectable = true;
         this.btnOk.Click += new System.EventHandler(this.metroButton1_Click);
         // 
         // btnCancel
         // 
         this.btnCancel.Location = new System.Drawing.Point(311, 372);
         this.btnCancel.Name = "btnCancel";
         this.btnCancel.Size = new System.Drawing.Size(78, 28);
         this.btnCancel.TabIndex = 11;
         this.btnCancel.Text = "取消(&C)";
         this.btnCancel.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.btnCancel.UseSelectable = true;
         // 
         // frmCreateCompendium
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
         this.ClientSize = new System.Drawing.Size(408, 414);
         this.Controls.Add(this.btnCancel);
         this.Controls.Add(this.btnOk);
         this.Controls.Add(this.txtStory);
         this.Controls.Add(this.txtPlace);
         this.Controls.Add(this.btnClearAll);
         this.Controls.Add(this.btnRemove);
         this.Controls.Add(this.btnAdd);
         this.Controls.Add(this.lstRoles);
         this.Controls.Add(this.cmbCategory);
         this.Controls.Add(this.metroLabel5);
         this.Controls.Add(this.metroLabel4);
         this.Controls.Add(this.metroLabel3);
         this.Controls.Add(this.metroLabel2);
         this.Controls.Add(this.metroLabel1);
         this.Controls.Add(this.hltDay);
         this.Controls.Add(this.hltMonth);
         this.Controls.Add(this.hltYear);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
         this.ImeMode = System.Windows.Forms.ImeMode.KatakanaHalf;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "frmCreateCompendium";
         this.Text = "创建故事线";
         this.Load += new System.EventHandler(this.frmCreateCompendium_Load);
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private HaveLabelTextBox hltYear;
      private MetroFramework.Controls.MetroLabel metroLabel1;
      private HaveLabelTextBox hltMonth;
      private HaveLabelTextBox hltDay;
      private MetroFramework.Controls.MetroLabel metroLabel2;
      private MetroFramework.Controls.MetroComboBox cmbCategory;
      private MetroFramework.Controls.MetroLabel metroLabel3;
      private MetroFramework.Controls.MetroButton btnAdd;
      private MetroFramework.Controls.MetroButton btnRemove;
      private MetroFramework.Controls.MetroButton btnClearAll;
      private MetroFramework.Controls.MetroLabel metroLabel4;
      private MetroFramework.Controls.MetroTextBox txtPlace;
      private MetroFramework.Controls.MetroLabel metroLabel5;
      private MetroFramework.Controls.MetroTextBox txtStory;
      private MetroFramework.Controls.MetroButton btnOk;
      private MetroFramework.Controls.MetroButton btnCancel;
      public System.Windows.Forms.ListBox lstRoles;
   }
}
