﻿namespace Cabinink.Writer.UI
{
   partial class frmIntelliSence
   {
      /// <summary>
      /// 必需的设计器变量。
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// 清理所有正在使用的资源。
      /// </summary>
      /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows 窗体设计器生成的代码

      /// <summary>
      /// 设计器支持所需的方法 - 不要修改
      /// 使用代码编辑器修改此方法的内容。
      /// </summary>
      private void InitializeComponent()
      {
         this.pnlBack = new System.Windows.Forms.Panel();
         this.lblRemarks = new System.Windows.Forms.Label();
         this.lstIntelliSence = new System.Windows.Forms.ListBox();
         this.pnlBack.SuspendLayout();
         this.SuspendLayout();
         // 
         // pnlBack
         // 
         this.pnlBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
         this.pnlBack.Controls.Add(this.lblRemarks);
         this.pnlBack.Location = new System.Drawing.Point(272, 29);
         this.pnlBack.Name = "pnlBack";
         this.pnlBack.Size = new System.Drawing.Size(277, 213);
         this.pnlBack.TabIndex = 2;
         // 
         // lblRemarks
         // 
         this.lblRemarks.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
         this.lblRemarks.ForeColor = System.Drawing.Color.White;
         this.lblRemarks.Location = new System.Drawing.Point(3, 2);
         this.lblRemarks.Name = "lblRemarks";
         this.lblRemarks.Size = new System.Drawing.Size(271, 211);
         this.lblRemarks.TabIndex = 4;
         this.lblRemarks.Text = "详细：";
         // 
         // lstIntelliSence
         // 
         this.lstIntelliSence.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
         this.lstIntelliSence.BorderStyle = System.Windows.Forms.BorderStyle.None;
         this.lstIntelliSence.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
         this.lstIntelliSence.ForeColor = System.Drawing.Color.White;
         this.lstIntelliSence.FormattingEnabled = true;
         this.lstIntelliSence.ItemHeight = 20;
         this.lstIntelliSence.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "0"});
         this.lstIntelliSence.Location = new System.Drawing.Point(6, 35);
         this.lstIntelliSence.Name = "lstIntelliSence";
         this.lstIntelliSence.Size = new System.Drawing.Size(262, 200);
         this.lstIntelliSence.TabIndex = 3;
         this.lstIntelliSence.Click += new System.EventHandler(this.lstIntelliSence_Click);
         this.lstIntelliSence.SelectedIndexChanged += new System.EventHandler(this.lstIntelliSence_SelectedIndexChanged);
         // 
         // frmIntelliSence
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
         this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
         this.ClientSize = new System.Drawing.Size(550, 243);
         this.Controls.Add(this.lstIntelliSence);
         this.Controls.Add(this.pnlBack);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "frmIntelliSence";
         this.Text = "IntelliSence";
         this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmIntelliSence_FormClosing);
         this.Load += new System.EventHandler(this.frmIntelliSence_Load);
         this.pnlBack.ResumeLayout(false);
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.Panel pnlBack;
      private System.Windows.Forms.Label lblRemarks;
      private System.Windows.Forms.ListBox lstIntelliSence;
   }
}
