﻿namespace Cabinink.Writer.UI
{
   partial class frmEditorSetting
   {
      /// <summary>
      /// 必需的设计器变量。
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// 清理所有正在使用的资源。
      /// </summary>
      /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows 窗体设计器生成的代码

      /// <summary>
      /// 设计器支持所需的方法 - 不要修改
      /// 使用代码编辑器修改此方法的内容。
      /// </summary>
      private void InitializeComponent()
      {
         this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
         this.cmbFontSize = new MetroFramework.Controls.MetroComboBox();
         this.metroButton1 = new MetroFramework.Controls.MetroButton();
         this.SuspendLayout();
         // 
         // metroLabel1
         // 
         this.metroLabel1.AutoSize = true;
         this.metroLabel1.Location = new System.Drawing.Point(21, 68);
         this.metroLabel1.Name = "metroLabel1";
         this.metroLabel1.Size = new System.Drawing.Size(65, 20);
         this.metroLabel1.TabIndex = 0;
         this.metroLabel1.Text = "字体大小";
         this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.metroLabel1.UseCustomBackColor = true;
         // 
         // cmbFontSize
         // 
         this.cmbFontSize.FontSize = MetroFramework.MetroComboBoxSize.Small;
         this.cmbFontSize.FormattingEnabled = true;
         this.cmbFontSize.ItemHeight = 21;
         this.cmbFontSize.Items.AddRange(new object[] {
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18"});
         this.cmbFontSize.Location = new System.Drawing.Point(92, 65);
         this.cmbFontSize.Name = "cmbFontSize";
         this.cmbFontSize.Size = new System.Drawing.Size(114, 27);
         this.cmbFontSize.TabIndex = 1;
         this.cmbFontSize.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.cmbFontSize.UseSelectable = true;
         // 
         // metroButton1
         // 
         this.metroButton1.Location = new System.Drawing.Point(127, 185);
         this.metroButton1.Name = "metroButton1";
         this.metroButton1.Size = new System.Drawing.Size(79, 29);
         this.metroButton1.TabIndex = 2;
         this.metroButton1.Text = "确定(&E)";
         this.metroButton1.Theme = MetroFramework.MetroThemeStyle.Dark;
         this.metroButton1.UseSelectable = true;
         // 
         // frmEditorSetting
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
         this.ClientSize = new System.Drawing.Size(231, 240);
         this.Controls.Add(this.metroButton1);
         this.Controls.Add(this.cmbFontSize);
         this.Controls.Add(this.metroLabel1);
         this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
         this.MaximizeBox = false;
         this.MinimizeBox = false;
         this.Name = "frmEditorSetting";
         this.Text = "编辑器设置";
         this.Load += new System.EventHandler(this.frmEditorSetting_Load);
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private MetroFramework.Controls.MetroLabel metroLabel1;
      private MetroFramework.Controls.MetroComboBox cmbFontSize;
      private MetroFramework.Controls.MetroButton metroButton1;
   }
}
