﻿using System;
using System.Xml;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Cabinink.Writer.Cores
{
   /// <summary>
   /// 主体部分XML存取类
   /// </summary>
   public class XmlNovelDocument
   {
      private Novel novel;
      private string documenturl;
      private XmlDocument document;
      public XmlNovelDocument(Novel _novel)
      {
         novel = _novel;
         documenturl = string.Empty;
         document = new XmlDocument();
      }
      public XmlNovelDocument(Novel _novel, string _docurl)
      {
         novel = _novel;
         documenturl = _docurl;
         document = new XmlDocument();
      }
      public XmlNovelDocument(Novel _novel, string _docurl, XmlDocument _xmldoc)
      {
         novel = _novel;
         documenturl = _docurl;
         document = _xmldoc;
      }
      public Novel CurrentNovel
      {
         get { return novel; }
         internal set { novel = value; }
      }
      public string DocumentUrl
      {
         get { return documenturl; }
         internal set { documenturl = value; }
      }
      public XmlDocument Document
      {
         get { return document; }
         internal set { document = value; }
      }
      public void LoadDocument()
      {
         Document.Load(@documenturl);
      }
   }
}
